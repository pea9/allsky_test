<?php
$dir = ".";
$prefix = "allsky";
$title = "Timelapse Videos";
include_once("../show_thumbnails.php");
?>
