<?php
$dir = ".";
$prefix = "keogram";
$title = "Keograms";
include_once("../show_thumbnails.php");
?>
